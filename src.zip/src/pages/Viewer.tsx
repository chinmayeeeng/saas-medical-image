import React from "react";
import ImageViewer from "../components/ImageViewer";
import AnnotationTool from "../components/AnnotationTool";

const Viewer: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Image Viewer</h1>
      <div className="mb-6">
        {/* Pass a placeholder image URL or dynamic data */}
        <ImageViewer imageUrl="/path-to-image.png" />
      </div>
      <AnnotationTool />
    </div>
  );
};

export default Viewer;
