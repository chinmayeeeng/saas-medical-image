import React from "react";

const About: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-center mb-6">
        About SaaS Medical Imaging
      </h1>
      <p className="text-lg text-center">
        SaaS Medical Imaging is a powerful and intuitive platform designed to
        simplify the process of working with medical images. With features like
        annotation tools, DICOM metadata extraction, and real-world
        measurement capabilities, our tool helps healthcare professionals and
        researchers streamline their workflows.
      </p>
    </div>
  );
};

export default About;
