import React from "react";
import { Link } from "react-router-dom";

const Home: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-center mb-6">
        Welcome to SaaS Medical Imaging
      </h1>
      <p className="text-lg text-center mb-8">
        This application provides tools to upload, view, annotate, and analyze
        medical images seamlessly.
      </p>
      <div className="text-center">
        <Link
          to="/viewer"
          className="bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-400"
        >
          Start Viewing Images
        </Link>
      </div>
    </div>
  );
};

export default Home;
