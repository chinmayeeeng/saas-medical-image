import React from "react";

interface MetadataProps {
  metadata: {
    patientName: string;
    studyDate: string;
    modality: string;
  };
}

const MetadataViewer: React.FC<MetadataProps> = ({ metadata }) => {
  return (
    <div className="bg-gray-800 text-white p-4 rounded">
      <h2 className="text-lg font-bold mb-2">DICOM Metadata</h2>
      <ul>
        <li>
          <strong>Patient Name:</strong> {metadata.patientName}
        </li>
        <li>
          <strong>Study Date:</strong> {metadata.studyDate}
        </li>
        <li>
          <strong>Modality:</strong> {metadata.modality}
        </li>
      </ul>
    </div>
  );
};

export default MetadataViewer;
