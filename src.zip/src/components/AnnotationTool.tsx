import React, { useRef, useState } from "react";
import { Stage, Layer, Rect, Circle } from "react-konva";
import Konva from "konva";

const AnnotationTool: React.FC = () => {
  const [shapes, setShapes] = useState<any[]>([]);
  const stageRef = useRef<Konva.Stage | null>(null); // Explicitly typing the useRef

  const addRectangle = () => {
    setShapes([
      ...shapes,
      { type: "rect", x: 50, y: 50, width: 100, height: 100, fill: "red" },
    ]);
  };

  const addCircle = () => {
    setShapes([
      ...shapes,
      { type: "circle", x: 150, y: 150, radius: 50, fill: "blue" },
    ]);
  };

  return (
    <div>
      <div className="mb-4">
        <button onClick={addRectangle} className="bg-teal-500 text-white px-4 py-2 rounded mr-2">
          Add Rectangle
        </button>
        <button onClick={addCircle} className="bg-purple-500 text-white px-4 py-2 rounded">
          Add Circle
        </button>
      </div>
      <Stage
        width={800}
        height={400}
        ref={stageRef} // Reference to the Konva Stage
        className="border border-gray-600"
      >
        <Layer>
          {shapes.map((shape, index) => {
            if (shape.type === "rect") {
              return (
                <Rect
                  key={index}
                  x={shape.x}
                  y={shape.y}
                  width={shape.width}
                  height={shape.height}
                  fill={shape.fill}
                  draggable
                />
              );
            } else if (shape.type === "circle") {
              return (
                <Circle
                  key={index}
                  x={shape.x}
                  y={shape.y}
                  radius={shape.radius}
                  fill={shape.fill}
                  draggable
                />
              );
            }
            return null;
          })}
        </Layer>
      </Stage>
    </div>
  );
};

export default AnnotationTool;
