import React from "react";

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white p-4 shadow-inner mt-8">
      <div className="container mx-auto text-center">
        <p>© 2025 SaaS Medical Imaging. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
