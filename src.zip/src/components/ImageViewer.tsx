import React, { useState } from "react";

interface ImageViewerProps {
  imageUrl: string;
}

const ImageViewer: React.FC<ImageViewerProps> = ({ imageUrl }) => {
  const [scale, setScale] = useState(1);
  const [translateX, setTranslateX] = useState(0);
  const [translateY, setTranslateY] = useState(0);

  const zoomIn = () => setScale(scale + 0.1);
  const zoomOut = () => setScale(Math.max(0.1, scale - 0.1));
  const reset = () => {
    setScale(1);
    setTranslateX(0);
    setTranslateY(0);
  };

  return (
    <div className="image-viewer">
      <div className="controls mb-4">
        <button onClick={zoomIn} className="bg-teal-500 text-white px-4 py-2 rounded mr-2">
          Zoom In
        </button>
        <button onClick={zoomOut} className="bg-purple-500 text-white px-4 py-2 rounded mr-2">
          Zoom Out
        </button>
        <button onClick={reset} className="bg-gray-700 text-white px-4 py-2 rounded">
          Reset
        </button>
      </div>
      <div
        className="image-container"
        style={{
          overflow: "hidden",
          border: "1px solid #ccc",
          height: "400px",
          position: "relative",
        }}
      >
        <img
          src={imageUrl}
          alt="Medical"
          style={{
            transform: `scale(${scale}) translate(${translateX}px, ${translateY}px)`,
            transition: "transform 0.2s ease",
          }}
        />
      </div>
    </div>
  );
};

export default ImageViewer;
