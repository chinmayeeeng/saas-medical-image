import dicomParser from "dicom-parser";

/**
 * Parse a DICOM file and extract its metadata
 * @param file - The DICOM file to parse
 * @returns Extracted metadata
 */
export const parseDicomFile = (file: File) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const arrayBuffer = reader.result as ArrayBuffer;
        const dataSet = dicomParser.parseDicom(new Uint8Array(arrayBuffer));
        const metadata = extractMetadata(dataSet);
        resolve(metadata);
      } catch (error) {
        console.error("Error parsing DICOM file:", error);
        reject(error);
      }
    };
    reader.onerror = (error) => {
      console.error("Error reading DICOM file:", error);
      reject(error);
    };
    reader.readAsArrayBuffer(file);
  });
};

/**
 * Extract relevant metadata from a DICOM data set
 * @param dataSet - The parsed DICOM data set
 * @returns Extracted metadata
 */
const extractMetadata = (dataSet: any) => {
  try {
    return {
      patientName: dataSet.string("x00100010") || "Unknown", // Patient's name
      studyDate: dataSet.string("x00080020") || "Unknown",  // Study date
      modality: dataSet.string("x00080060") || "Unknown",   // Imaging modality
      pixelSpacing: dataSet.string("x00280030") || "Unknown", // Pixel spacing
    };
  } catch (error) {
    console.error("Error extracting metadata:", error);
    throw error;
  }
};

/**
 * Convert pixel spacing to real-world measurements
 * @param pixelSpacing - The pixel spacing (mm/pixel)
 * @param pixelDistance - The distance in pixels
 * @returns Real-world distance in millimeters
 */
export const calculateRealWorldDistance = (pixelSpacing: string, pixelDistance: number) => {
  if (!pixelSpacing) {
    console.error("Pixel spacing is required to calculate real-world distance.");
    return null;
  }

  try {
    const spacingValues = pixelSpacing.split("\\").map(Number);
    const averageSpacing = spacingValues.reduce((sum, value) => sum + value, 0) / spacingValues.length;
    return pixelDistance * averageSpacing; // Distance in millimeters
  } catch (error) {
    console.error("Error calculating real-world distance:", error);
    return null;
  }
};
