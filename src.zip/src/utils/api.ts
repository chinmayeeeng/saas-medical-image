import axios from "axios";

// Base API configuration
const API = axios.create({
  baseURL: "http://localhost:5000/api", // Adjust base URL as per your backend setup
  headers: {
    "Content-Type": "application/json",
  },
});

/**
 * Upload an image to the server
 * @param file - The image file to upload
 * @returns Response from the server
 */
export const uploadImage = async (file: File) => {
  const formData = new FormData();
  formData.append("image", file);

  try {
    const response = await API.post("/images/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error uploading image:", error);
    throw error;
  }
};

/**
 * Fetch metadata for a given DICOM file
 * @param fileId - The ID of the uploaded file
 * @returns DICOM metadata from the server
 */
export const fetchDicomMetadata = async (fileId: string) => {
  try {
    const response = await API.get(`/dicom/metadata/${fileId}`);
    return response.data;
  } catch (error) {
    console.error("Error fetching DICOM metadata:", error);
    throw error;
  }
};

/**
 * Save annotations for a given image
 * @param fileId - The ID of the image file
 * @param annotations - Annotations data to save
 * @returns Response from the server
 */
export const saveAnnotations = async (fileId: string, annotations: any) => {
  try {
    const response = await API.post(`/annotations/save/${fileId}`, { annotations });
    return response.data;
  } catch (error) {
    console.error("Error saving annotations:", error);
    throw error;
  }
};
