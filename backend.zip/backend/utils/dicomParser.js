const dicomParser = require("dicom-parser");
const fs = require("fs");

/**
 * Parse a DICOM file and extract metadata
 * @param {string} filePath - Path to the DICOM file
 * @returns {object} Extracted metadata
 */
const parseDicomFile = (filePath) => {
  if (!fs.existsSync(filePath)) {
    throw new Error("File not found");
  }

  try {
    const fileBuffer = fs.readFileSync(filePath);
    const dataSet = dicomParser.parseDicom(fileBuffer);

    // Extract metadata
    const metadata = {
      patientName: dataSet.string("x00100010") || "Unknown",
      studyDate: dataSet.string("x00080020") || "Unknown",
      modality: dataSet.string("x00080060") || "Unknown",
      pixelSpacing: dataSet.string("x00280030") || "Unknown",
      imageWidth: dataSet.uint16("x00280011") || "Unknown",
      imageHeight: dataSet.uint16("x00280010") || "Unknown",
    };

    return metadata;
  } catch (error) {
    console.error("Error parsing DICOM file:", error);
    throw new Error("Failed to parse DICOM file");
  }
};

module.exports = { parseDicomFile };
