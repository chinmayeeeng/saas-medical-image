const sharp = require("sharp");

/**
 * Resize an image
 * @param {Buffer} imageBuffer - Image file as a buffer
 * @param {number} width - Desired width
 * @param {number} height - Desired height
 * @returns {Buffer} Resized image buffer
 */
const resizeImage = async (imageBuffer, width, height) => {
  try {
    const resizedImage = await sharp(imageBuffer).resize(width, height).toBuffer();
    return resizedImage;
  } catch (error) {
    console.error("Error resizing image:", error);
    throw new Error("Failed to resize image");
  }
};

/**
 * Crop an image
 * @param {Buffer} imageBuffer - Image file as a buffer
 * @param {number} left - X-coordinate of the top-left corner
 * @param {number} top - Y-coordinate of the top-left corner
 * @param {number} width - Width of the cropped region
 * @param {number} height - Height of the cropped region
 * @returns {Buffer} Cropped image buffer
 */
const cropImage = async (imageBuffer, left, top, width, height) => {
  try {
    const croppedImage = await sharp(imageBuffer)
      .extract({ left, top, width, height })
      .toBuffer();
    return croppedImage;
  } catch (error) {
    console.error("Error cropping image:", error);
    throw new Error("Failed to crop image");
  }
};

/**
 * Adjust image brightness and contrast
 * @param {Buffer} imageBuffer - Image file as a buffer
 * @param {number} brightness - Brightness adjustment factor (-1 to 1)
 * @param {number} contrast - Contrast adjustment factor (-1 to 1)
 * @returns {Buffer} Adjusted image buffer
 */
const adjustImage = async (imageBuffer, brightness = 0, contrast = 0) => {
  try {
    const adjustedImage = await sharp(imageBuffer)
      .modulate({
        brightness: 1 + brightness,
        contrast: 1 + contrast,
      })
      .toBuffer();
    return adjustedImage;
  } catch (error) {
    console.error("Error adjusting image:", error);
    throw new Error("Failed to adjust image");
  }
};

module.exports = { resizeImage, cropImage, adjustImage };
