// In-memory storage for annotations (replace with a database in production)
const annotations = {};

// Save annotations for a specific image
exports.saveAnnotations = (req, res) => {
  const fileName = req.params.fileName;
  const annotationData = req.body.annotations;

  if (!annotationData) {
    return res.status(400).json({ error: "No annotation data provided" });
  }

  annotations[fileName] = annotationData;

  res.status(200).json({ message: "Annotations saved successfully" });
};

// Retrieve annotations for a specific image
exports.getAnnotations = (req, res) => {
  const fileName = req.params.fileName;

  if (!annotations[fileName]) {
    return res.status(404).json({ error: "Annotations not found" });
  }

  res.status(200).json(annotations[fileName]);
};
