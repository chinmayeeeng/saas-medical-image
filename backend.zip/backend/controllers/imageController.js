const path = require("path");
const fs = require("fs");

// Upload an image file
exports.uploadImage = (req, res) => {
  if (!req.files || !req.files.image) {
    return res.status(400).json({ error: "No image file uploaded" });
  }

  const image = req.files.image;
  const uploadPath = path.join(__dirname, "../uploads", image.name);

  // Save the uploaded file
  image.mv(uploadPath, (err) => {
    if (err) {
      console.error("Error uploading file:", err);
      return res.status(500).json({ error: "Failed to upload image" });
    }

    res.status(200).json({
      message: "Image uploaded successfully",
      filePath: `/uploads/${image.name}`,
    });
  });
};

// Get the list of uploaded images
exports.getUploadedImages = (req, res) => {
  const uploadDir = path.join(__dirname, "../uploads");

  fs.readdir(uploadDir, (err, files) => {
    if (err) {
      console.error("Error reading uploads directory:", err);
      return res.status(500).json({ error: "Failed to fetch uploaded images" });
    }

    res.status(200).json({ images: files });
  });
};
