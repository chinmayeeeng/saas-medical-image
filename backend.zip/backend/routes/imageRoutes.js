const express = require("express");
const router = express.Router();
const path = require("path");
const fs = require("fs");

// Endpoint to upload an image
router.post("/upload", (req, res) => {
  if (!req.files || !req.files.image) {
    return res.status(400).json({ error: "No image file uploaded" });
  }

  const image = req.files.image;
  const uploadPath = path.join(__dirname, "../uploads", image.name);

  // Save the uploaded file
  image.mv(uploadPath, (err) => {
    if (err) {
      console.error("Error uploading file:", err);
      return res.status(500).json({ error: "Failed to upload image" });
    }

    res.status(200).json({
      message: "Image uploaded successfully",
      filePath: `/uploads/${image.name}`,
    });
  });
});

module.exports = router;
