const express = require("express");
const router = express.Router();
const dicomParser = require("dicom-parser");
const fs = require("fs");
const path = require("path");

// Endpoint to fetch metadata from a DICOM file
router.get("/metadata/:fileName", (req, res) => {
  const fileName = req.params.fileName;
  const filePath = path.join(__dirname, "../uploads", fileName);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: "DICOM file not found" });
  }

  try {
    const fileBuffer = fs.readFileSync(filePath);
    const dataSet = dicomParser.parseDicom(fileBuffer);

    const metadata = {
      patientName: dataSet.string("x00100010") || "Unknown",
      studyDate: dataSet.string("x00080020") || "Unknown",
      modality: dataSet.string("x00080060") || "Unknown",
      pixelSpacing: dataSet.string("x00280030") || "Unknown",
    };

    res.status(200).json(metadata);
  } catch (error) {
    console.error("Error parsing DICOM file:", error);
    res.status(500).json({ error: "Failed to parse DICOM file" });
  }
});

module.exports = router;
