const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

// In-memory storage for annotations (replace with a database in production)
const annotations = {};

// Endpoint to save annotations
router.post("/save/:fileName", (req, res) => {
  const fileName = req.params.fileName;
  const annotationData = req.body.annotations;

  if (!annotationData) {
    return res.status(400).json({ error: "No annotation data provided" });
  }

  annotations[fileName] = annotationData;

  res.status(200).json({ message: "Annotations saved successfully" });
});

// Endpoint to retrieve annotations
router.get("/:fileName", (req, res) => {
  const fileName = req.params.fileName;

  if (!annotations[fileName]) {
    return res.status(404).json({ error: "Annotations not found" });
  }

  res.status(200).json(annotations[fileName]);
});

module.exports = router;
