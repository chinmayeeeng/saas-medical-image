const express = require("express");
const fs = require("fs");
const path = require("path");

const router = express.Router();

// Serve uploaded files
router.get("/:fileName", (req, res) => {
  const fileName = req.params.fileName;
  const filePath = path.join(__dirname, fileName);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: "File not found" });
  }

  res.sendFile(filePath, (err) => {
    if (err) {
      console.error("Error serving file:", err);
      res.status(500).json({ error: "Error serving file" });
    }
  });
});

// List all files in the uploads directory
router.get("/", (req, res) => {
  const uploadDir = __dirname;

  fs.readdir(uploadDir, (err, files) => {
    if (err) {
      console.error("Error reading uploads directory:", err);
      return res.status(500).json({ error: "Failed to list uploaded files" });
    }

    res.status(200).json({ files });
  });
});

module.exports = router;
